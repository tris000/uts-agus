<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Employee;

class EmployesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $employee = new employee;
        $employee->nip = '222000910001';
        $employee->name = 'Agus Trisna';
        $employee->date_of_birth = '10-3-2004';
        $employee->place_of_birth ='Pekutatan';
        $employee->address = 'Pekutatan';
        $employee->email = 'agustrisna788@gmail.com';
        $employee->phone_number = '081234567890';
        $employee->salary = '100.000';
        $employee->status =  'active';
        $employee->save();
        
        // DB::table('employees')->insert([
        //     'nip'  => '222000910001',
        //     'name' => 'Agus Trisna',
        //     'date_of_birth' => '10-3-2004',
        //     'place_of_birth' => 'Pekutatan',
        //     'address' => 'Pekutatan',
        //     'email' => 'agustrisna788@gmail.com',
        //     'phone_number' => '081234567890',
        //     'salary' => '100.000',
        //     'status' => 'active'
        // ]);
    
    
       // DB::table('employees')->insert([
        //     'nip'  => '222000910001',
        //     'name' => 'Agus Trisna2',
        //     'date_of_birth' => '10-3-2004',
        //     'place_of_birth' => 'Pekutatan',
        //     'address' => 'Pekutatan',
        //     'email' => 'agustrisna788@gmail.com',
        //     'phone_number' => '081234567890',
        //     'salary' => '150.000',
        //     'status' => 'inactive'
        // ]);
    }
}
